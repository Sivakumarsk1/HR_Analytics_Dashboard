from flask import Flask, render_template
import pandas as pd
import plotly.express as px

app = Flask(__name__)

# Load dataset
df = pd.read_csv("marital_status_vs_attrition_professional.csv")


@app.route("/")
def dashboard():

    # ================= KPI CARDS =================
    total_emp = df["TotalEmployees"].sum()
    total_attrition = df["AttritionCount"].sum()
    attrition_rate = round((total_attrition / total_emp) * 100, 2)

    # ================= CHART =================
    fig = px.bar(
        df,
        x="MaritalStatus",
        y="AttritionRatePercent",
        color="MaritalStatus",
        text="AttritionRatePercent",
        template="plotly_dark",
        title="Marital Status vs Attrition Rate (%)"
    )

    fig.update_layout(height=500)
    fig.update_traces(texttemplate='%{text}%', textposition='outside')

    graph_html = fig.to_html(full_html=False)

    return render_template(
        "dashboard.html",
        graph_html=graph_html,
        total_emp=total_emp,
        attrition_rate=attrition_rate,
        total_attrition=total_attrition
    )


if __name__ == "__main__":
    app.run(debug=True)
